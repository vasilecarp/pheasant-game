import './App.css';
import PheasantGame from "./PheasantGame";

function App() {
  return (
    <div className="App">
      <PheasantGame />
    </div>
  );
}

export default App;
